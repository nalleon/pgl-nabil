export const URL_INSTITUTO = "http://172.16.0.110:8080/instituto/api/";
//10.108.9.0
//172.16.0.110
//192.168.168.207
//npm install react-native-date-picker
//npm install react-native-image-picker