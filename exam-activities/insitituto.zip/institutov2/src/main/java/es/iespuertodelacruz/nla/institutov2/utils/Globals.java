package es.iespuertodelacruz.nla.institutov2.utils;
/**
 * @author Nabil Leon Alvarez <@nalleon>
 */

public class Globals {
    public static final String LOGGER_ALUMNO = "alumno";
    public static final String LOGGER_MATRICULA = "matricula";
    public static final String LOGGER_ASIGNATURA = "asignatura";
    public static final String LOGGER_USUARIO = "usuario";
    public static final String LOGGER_AUTH = "auth";

}
