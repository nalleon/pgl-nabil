package es.iespuertodelacruz.nla.institutov2.dto;

import java.util.Date;

/**
 * @author Nabil Leon Alvarez <@nalleon>
 */
public record AlumnoDTOV2(String nombre, String apellidos){};
