package es.iespuertodelacruz.nla.institutov2.dto;

/**
 * @author Nabil Leon Alvarez <@nalleon>
 */
public record AsignaturaDTO(String curso, String nombre){
}
