package es.iespuertodelacruz.nla.institutov2.dto;

/**
 * @author Nabil Leon Alvarez <@nalleon>
 */
public record AlumnoOutputDTOV3(String dni, String nombre, String apellidos){};
