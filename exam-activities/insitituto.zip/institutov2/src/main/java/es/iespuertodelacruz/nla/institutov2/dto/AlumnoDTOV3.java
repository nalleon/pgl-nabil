package es.iespuertodelacruz.nla.institutov2.dto;

import java.util.Date;

/**
 * @author Nabil Leon Alvarez <@nalleon>
 */

public record AlumnoDTOV3(String dni, String apellidos, Date fechanacimiento, String nombre){};
