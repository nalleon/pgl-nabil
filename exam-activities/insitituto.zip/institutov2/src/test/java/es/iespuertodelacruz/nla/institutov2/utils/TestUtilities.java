package es.iespuertodelacruz.nla.institutov2.utils;

public class TestUtilities {

    public static  final String MESSAGE_ERROR = "Expected result not found";
}
