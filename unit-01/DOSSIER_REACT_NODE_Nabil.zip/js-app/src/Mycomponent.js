import logo from './logo.svg';
import React from "react";

/**
 * 
 * @returns Example React component that renders a header with a logo and a link to Learn React.
 */
function Mycomponent() {
    return (
      <div className="App">
            <h1>Hello world </h1>
      </div>
    );
  }
  
  export default Mycomponent;
  