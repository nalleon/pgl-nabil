import React from 'react'

type Props = {}

const Practice11 = (props: Props) => {
  return (
    <div>Practice11</div>
  )
}

export default Practice11