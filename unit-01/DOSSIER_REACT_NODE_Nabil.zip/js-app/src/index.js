import React from 'react';
import ReactDOM from 'react-dom';
/**
//import Practice09 from './practice09/Practice09.tsx';
import Practice20 from './practice20/Practice20.tsx';
import Practice21 from './practice21/Practice21.tsx';
import EjemploUseRef from './practice23/Example.tsx';
import Practice24 from './practice24/Practice24.tsx';
import IntervalExample from './examples/ItervalExample.tsx';
import BetNumGame from './components/BetNumGame.tsx';
import Practice28 from './practice28/Practice28.tsx';
import Practica29 from './practice29/Practica29.tsx';
import Practice30 from './practice30/Practice30.tsx';
import Practice31 from './practice31/Practice31.tsx';
import Practice26 from './practice26/Practice26.tsx';
import Practice22 from './practice22/Practice22.tsx';
import Practice23 from './practice23/Practice23.tsx';
//import Practice31Refactor from './practice31/Practice31Refactor.tsx';
import PadreModificadoPorHijo from './examples/ComponentesHijosPadres.tsx';
import Practice35 from './practice35/Practice35.tsx';
import Practice32 from './practice32/Practice32.tsx';
import Practice33 from './practice33/Practice33.tsx';
import Practice34 from './practice34/Practica34.tsx';
//import Practice36 from './practice36/Practice36.tsx';
import Practice35Refactor from './practice35/Practice35Refactor.tsx';
import Practice37 from './practice37/Practice37.tsx';
import Practice38 from './practice38/Practice38.tsx';
import Practice39 from './practice39/Practice39.tsx';
 */
//import Practice41 from './practice41/Practice41.tsx';
//import Practice39 from './practice39/Practice39.tsx';
//import Practice38 from './practice38/Practice38.tsx';
//import { BrowserRouter } from 'react-router-dom';
//import Practice27 from './practice27/Practice27.tsx';
//import Practice42 from './practice42/Practice42.tsx';
import Practice43 from './practice43/Components/Practice43.tsx';
import CapitalList from './practice44/Components/CapitalList.tsx';
import Practice45 from './practice45/Components/App.tsx';
import CapitalApp from './practice46/Components/CapitalApp.tsx';
import CapitalApp47 from './practice47/Components/CapitalApp47.tsx';
import Practice21 from './practice21/Practice21.tsx';
import Watch22 from './practice22/Watch22.tsx';
import App50 from './practice50/Components/App50.tsx';
import CapitalApp51 from './practice51/CapitalApp51.tsx';
import Practice27 from './practice27/Practice27.tsx';
import Practice25 from './practice25/Practice25.tsx';
import App52 from './practice52/App52.tsx';
import Practice48 from './practice48/Components/PersonList.tsx';
import App48 from './practice48/Components/App48.tsx';
//import Practice18 from './practice18/practice18.tsx';

//import ComponenteApp from './ComponenteApp.js';

const divRoot = document.getElementById("root");
ReactDOM.render(
  //<React.StrictMode>
  //<BrowserRouter>
  <Practice21/>, divRoot
  //</BrowserRouter>, divRoot
  //</React.StrictMode>

);
