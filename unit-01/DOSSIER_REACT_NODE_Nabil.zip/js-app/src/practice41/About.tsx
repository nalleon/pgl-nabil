import React from 'react'

type Props = {}

const About = (props: Props) => {
  return (
    <>
        <h1>About me</h1>
        <p><b>Name:</b> Nabil</p>
        <p><b>Surname:</b> León Álvarez</p>
        <p><b>Class:</b> 2ºDAM</p>
    </>
  )
}

export default About