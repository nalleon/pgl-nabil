import React from 'react'

type Props = {}

const RouterExample = (props: Props) => {
  return (
    <div>RouterExample</div>
  )
}

export default RouterExample