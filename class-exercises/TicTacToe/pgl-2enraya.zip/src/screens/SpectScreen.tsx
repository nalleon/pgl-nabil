import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const SpectScreen = (props: Props) => {
  return (
    <View>
      <Text>SpectScreen</Text>
    </View>
  )
}

export default SpectScreen

const styles = StyleSheet.create({})