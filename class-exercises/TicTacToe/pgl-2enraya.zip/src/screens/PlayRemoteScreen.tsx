import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const PlayRemoteScreen = (props: Props) => {
  return (
    <View>
      <Text>PlayRemoteScreen</Text>
    </View>
  )
}

export default PlayRemoteScreen

const styles = StyleSheet.create({})