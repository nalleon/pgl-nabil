import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

type Props = {}

const RemoteHomeScreen = (props: Props) => {
  return (
    <View>
      <Text>RemoteHomeScreen</Text>
    </View>
  )
}

export default RemoteHomeScreen

const styles = StyleSheet.create({})