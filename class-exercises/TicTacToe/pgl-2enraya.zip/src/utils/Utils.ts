export const URL_API = "http://10.108.1.0:8080/tictactoe/api/";
